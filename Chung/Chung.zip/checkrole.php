<?php
	if ($_SESSION["role"] == "admin") {
		echo "<a href="."../Chung/quantri.php".">Trang quản trị</a>";
	}
 ?>

