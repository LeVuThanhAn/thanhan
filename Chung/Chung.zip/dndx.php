
<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<?php
		if (!isset($_SESSION["role"])) {?>
			<form method="POST"><input type="submit" name="dn" value="Đăng Nhập"></form>
			<?php if (isset($_POST['dn'])) {
				header('Location: bt9.php');
				exit();
			} 
		} 
		?>
		<?php
		if (isset($_SESSION["role"])) { ?>
			<form method="POST"><input type='submit' name='dx' value='Đăng xuất'></form>
			<?php if (isset($_POST['dx'])) {
				session_unset();
				header('Location: bt9.php');
			}
		} 

	?>

</body>
</html>
