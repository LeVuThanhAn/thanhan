<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1>Chỉ admin mới có thể truy cập trang này!!!</h1>
</body>
</html>